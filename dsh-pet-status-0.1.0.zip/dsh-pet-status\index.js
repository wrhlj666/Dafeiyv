/**
 * dsh-pet-status — 把 DeepSeek Harness 的真实工作状态写成状态文件，供桌面桌宠读取。
 *
 * 这是一个独立实现：不依赖任何第三方桌宠插件，不启动任何子进程，
 * 只订阅 DSH 的全局 session/event，把状态归约成一行 JSON 追加到状态文件。
 *
 * 状态文件格式（JSONL，一行一条，UTF-8）：
 *   {"protocolVersion":1,"kind":"state","state":"WORKING","detail":"...","project":"...","toolName":"...","progress":{"completed":1,"total":3},"timestamp":1700000000000}
 *
 * 桌面端只需按行读取、取最后一条 kind === "state" 的消息即可。
 */

import { appendFileSync, mkdirSync, statSync, truncateSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { homedir } from 'node:os'

export const name = 'dsh-pet-status'
export const inject = ['sessions']

const PROTOCOL_VERSION = 1

export const CompanionState = Object.freeze({
  IDLE: 'IDLE',
  THINKING: 'THINKING',
  WORKING: 'WORKING',
  WAITING: 'WAITING',
  SUCCESS: 'SUCCESS',
  ERROR: 'ERROR',
})

/** 多会话时谁更值得展示（越大越优先） */
const STATE_PRIORITY = Object.freeze({
  WAITING: 60,
  ERROR: 50,
  WORKING: 30,
  THINKING: 20,
  IDLE: 0,
})

/** 状态文件超过该大小就清空重写，避免无限增长 */
const MAX_FILE_BYTES = 4 * 1024 * 1024

export function defaultStatusFile() {
  const base = process.env.LOCALAPPDATA || process.env.XDG_STATE_HOME || homedir()
  return join(base, 'dsh-pet-status', 'status.jsonl')
}

// ---------- 会话/事件字段提取（对字段缺失尽量宽容） ----------

function sessionIdOf(session) {
  return String(session?.header?.id ?? session?.id ?? 'unknown-session')
}

function isSubagent(session) {
  return session?.header?.origin === 'subagent'
    || Number(session?.header?.delegationDepth ?? 0) > 0
}

function cleanName(value) {
  const text = String(value ?? '').trim()
  if (!text) return ''
  const parts = text.split(/[\\/]/u).filter(Boolean)
  const candidate = parts.length > 1 ? parts[parts.length - 1] : text
  return candidate.replace(/\s+/gu, ' ').slice(0, 40)
}

function projectNameOf(session, event) {
  const candidates = [
    session?.header?.title,
    session?.header?.name,
    session?.title,
    session?.name,
    session?.header?.cwd,
    session?.cwd,
    event?.data?.projectName,
    event?.data?.cwd,
  ]
  for (const candidate of candidates) {
    const cleaned = cleanName(candidate)
    if (cleaned) return cleaned
  }
  return ''
}

function toolNameOf(event) {
  return String(event?.data?.name ?? event?.data?.message?.name ?? 'tool')
}

function toolCallIdOf(event) {
  const content = event?.data?.message?.content
  const fromContent = Array.isArray(content)
    ? content.find((item) => item?.toolCallId)?.toolCallId
    : undefined
  return String(event?.data?.message?.source?.callId
    ?? fromContent
    ?? event?.data?.message?.toolCallId
    ?? event?.data?.message?.callId
    ?? event?.data?.callId
    ?? `seq-${String(event?.seq ?? 'unknown')}`)
}

function isUserQuestionTool(toolName) {
  const value = String(toolName || '').toLowerCase()
  return /ask.*user.*question|request.*user.*input|user[-_/.:]?questions?/u.test(value)
}

function activityOf(toolName) {
  const value = String(toolName || '').toLowerCase()
  if (/search|grep|find|glob|web|read|fetch|open/.test(value)) return 'searching'
  if (/write|edit|patch|replace|create|move|delete/.test(value)) return 'editing'
  if (/test|check|lint|build|verify/.test(value)) return 'testing'
  if (/shell|bash|exec|command|terminal|pwsh|powershell/.test(value)) return 'commanding'
  return 'using-tool'
}

const ACTIVITY_STAGE = Object.freeze({
  searching: '查找阶段',
  editing: '修改阶段',
  testing: '验证阶段',
  commanding: '执行阶段',
  'using-tool': '执行阶段',
})

function progressOf(todos) {
  if (!Array.isArray(todos) || todos.length === 0) return undefined
  const completed = todos.filter((todo) => ['completed', 'complete', 'done'].includes(todo?.status)).length
  return { completed, total: todos.length }
}

// ---------- 归约器 ----------

export class StatusReducer {
  constructor({ includeSubagents = false } = {}) {
    this.includeSubagents = includeSubagents
    this.sessions = new Map()
    this.clock = 0
  }

  /** 处理一条会话事件，返回要写入的状态消息（可能为空数组） */
  handle(session, event) {
    if (!event || typeof event.type !== 'string') return []
    if (!this.includeSubagents && isSubagent(session)) return []

    const id = sessionIdOf(session)
    const record = this.#record(id)
    record.project = projectNameOf(session, event) || record.project
    if (event.seq !== undefined) record.lastSeq = Number(event.seq)

    switch (event.type) {
      case 'turn/start':
        record.turnActive = true
        record.openTools.clear()
        record.waitingCallId = ''
        record.task = ''
        record.progress = undefined
        return this.#update(record, CompanionState.THINKING, { stage: '准备阶段', phase: 'turn-start' })

      case 'step/start':
      case 'assistant/chunk':
      case 'assistant/message':
        if (!record.turnActive || record.openTools.size > 0) return []
        if (record.state === CompanionState.THINKING && record.payload.phase === 'thinking') return []
        return this.#update(record, CompanionState.THINKING, { stage: '分析阶段', phase: 'thinking' })

      case 'tool/call': {
        const callId = toolCallIdOf(event)
        const toolName = toolNameOf(event)
        record.openTools.set(callId, toolName)
        if (isUserQuestionTool(toolName)) {
          record.waitingCallId = callId
          return this.#update(record, CompanionState.WAITING, {
            stage: '等待确认',
            phase: 'user-question',
            toolName,
          })
        }
        return this.#update(record, CompanionState.WORKING, {
          stage: ACTIVITY_STAGE[activityOf(toolName)],
          phase: 'tool-call',
          activity: activityOf(toolName),
          toolName,
        })
      }

      case 'tool/result': {
        const callId = toolCallIdOf(event)
        record.openTools.delete(callId)
        if (callId === record.waitingCallId) record.waitingCallId = ''
        // 工具级失败不打扰桌宠（否则报错刷屏），只有整轮失败才进 ERROR
        return this.#resume(record)
      }

      case 'user/message':
        if (record.waitingCallId) {
          record.openTools.delete(record.waitingCallId)
          record.waitingCallId = ''
        }
        return this.#resume(record)

      case 'todo/write': {
        const todos = Array.isArray(event.data?.todos) ? event.data.todos : []
        const current = todos.find((todo) => todo?.status === 'in_progress')
          ?? todos.find((todo) => todo?.status === 'pending')
        const progress = progressOf(todos)
        const nextTask = current?.content ? String(current.content) : record.task
        const unchanged = nextTask === record.task
          && progress?.completed === record.progress?.completed
          && progress?.total === record.progress?.total
        if (unchanged) return []
        record.task = nextTask
        record.progress = progress
        record.updatedAt = ++this.clock
        const selection = this.#select()
        if (selection.record.id !== record.id) return this.#render(selection)
        return [this.#message(record)]
      }

      case 'turn/end': {
        record.turnActive = false
        record.openTools.clear()
        record.waitingCallId = ''
        const kind = String(event.data?.reason?.kind ?? 'completed')

        if (kind === 'blocked') {
          return this.#update(record, CompanionState.WAITING, { stage: '等待确认', phase: 'turn-end' })
        }
        if (kind === 'aborted') {
          return this.#update(record, CompanionState.IDLE, { stage: '已停止', phase: 'turn-end' })
        }
        if (kind !== 'completed') {
          return this.#update(record, CompanionState.ERROR, { stage: '需要处理', phase: 'turn-end' })
        }

        // 成功：先发一条 SUCCESS（让桌宠庆祝），再落回 IDLE
        record.state = CompanionState.IDLE
        record.payload = { stage: '已完成', phase: 'turn-end' }
        record.updatedAt = ++this.clock
        const success = {
          ...this.#message(record),
          state: CompanionState.SUCCESS,
          detail: this.#detail(record, '本轮已完成'),
        }
        return [success, this.#message(record)]
      }

      default:
        return []
    }
  }

  disposeSession(session) {
    const existed = this.sessions.delete(sessionIdOf(session))
    if (!existed) return []
    return this.#render(this.#select())
  }

  // ---- 内部 ----

  #resume(record) {
    const next = record.openTools.size > 0 ? CompanionState.WORKING : CompanionState.THINKING
    if (next === CompanionState.WORKING) {
      const toolName = record.openTools.values().next().value
      return this.#update(record, next, {
        stage: ACTIVITY_STAGE[activityOf(toolName)],
        phase: 'tool-result',
        activity: activityOf(toolName),
        toolName,
      })
    }
    return this.#update(record, next, { stage: '整理阶段', phase: 'tool-result' })
  }

  #record(id) {
    let record = this.sessions.get(id)
    if (record) return record
    record = {
      id,
      state: CompanionState.IDLE,
      payload: { stage: '空闲中', phase: 'session-created' },
      turnActive: false,
      openTools: new Map(),
      waitingCallId: '',
      task: '',
      progress: undefined,
      project: '',
      lastSeq: -1,
      updatedAt: ++this.clock,
    }
    this.sessions.set(id, record)
    return record
  }

  #update(record, state, payload) {
    record.state = state
    record.payload = payload
    record.updatedAt = ++this.clock
    return this.#render(this.#select())
  }

  /** 多会话时挑最需要注意的那个 */
  #select() {
    const records = [...this.sessions.values()]
    if (records.length === 0) {
      return {
        record: {
          id: 'dsh-host',
          state: CompanionState.IDLE,
          payload: { stage: '空闲中', phase: 'no-session' },
          project: '',
          task: '',
          progress: undefined,
          updatedAt: ++this.clock,
        },
      }
    }
    records.sort((left, right) => {
      const diff = (STATE_PRIORITY[right.state] ?? 0) - (STATE_PRIORITY[left.state] ?? 0)
      return diff || right.updatedAt - left.updatedAt || left.id.localeCompare(right.id)
    })
    return { record: records[0] }
  }

  #detail(record, fallback) {
    const parts = []
    if (record.project) parts.push(record.project)
    if (record.progress?.total) parts.push(`已完成 ${record.progress.completed}/${record.progress.total} 步`)
    if (record.task) parts.push(record.task)
    else if (record.payload?.stage) parts.push(record.payload.stage)
    return parts.join(' · ') || fallback || 'DSH 任务'
  }

  #message(record) {
    return {
      protocolVersion: PROTOCOL_VERSION,
      kind: 'state',
      timestamp: Date.now(),
      sessionId: record.id,
      state: record.state,
      phase: record.payload?.phase,
      stage: record.payload?.stage,
      activity: record.payload?.activity,
      toolName: record.payload?.toolName,
      project: record.project || undefined,
      task: record.task || undefined,
      progress: record.progress,
      detail: this.#detail(record),
    }
  }

  #render(selection) {
    return [this.#message(selection.record)]
  }
}

// ---------- 插件入口 ----------

export function apply(ctx, config = {}) {
  const logger = ctx.logger ?? console
  if (config.enabled === false) return

  const statusFile = config.statusFile || defaultStatusFile()
  const reducer = new StatusReducer({ includeSubagents: config.includeSubagents === true })

  try {
    mkdirSync(dirname(statusFile), { recursive: true })
  } catch (error) {
    logger.warn?.(`dsh-pet-status: 无法创建状态目录：${error instanceof Error ? error.message : String(error)}`)
    return
  }

  const write = (messages) => {
    if (!messages || messages.length === 0) return
    try {
      // 文件过大就清空重写（桌面端按增量读取，遇到截断会自动从头读）
      try {
        if (statSync(statusFile).size > MAX_FILE_BYTES) truncateSync(statusFile, 0)
      } catch {
        // 文件还不存在，忽略
      }
      const payload = messages.map((message) => `${JSON.stringify(message)}\n`).join('')
      appendFileSync(statusFile, payload, 'utf8')
    } catch (error) {
      logger.warn?.(`dsh-pet-status: 写状态文件失败：${error instanceof Error ? error.message : String(error)}`)
    }
  }

  ctx.effect(() => {
    const offEvent = ctx.on('session/event', (session, event) => {
      try {
        write(reducer.handle(session, event))
      } catch (error) {
        logger.warn?.(`dsh-pet-status: 处理事件失败：${error instanceof Error ? error.message : String(error)}`)
      }
    }, { global: true })

    const offDisposed = ctx.on('session/disposed', (session) => {
      try {
        write(reducer.disposeSession(session))
      } catch {
        // 忽略
      }
    }, { global: true })

    // 启动时先写一条 IDLE，让桌面端立刻有确定状态
    write([{
      protocolVersion: PROTOCOL_VERSION,
      kind: 'state',
      timestamp: Date.now(),
      sessionId: 'dsh-host',
      state: CompanionState.IDLE,
      stage: '空闲中',
      detail: 'DSH 已连接',
    }])

    logger.info?.(`dsh-pet-status: 已就绪，状态文件 ${statusFile}`)

    return () => {
      offEvent?.()
      offDisposed?.()
    }
  })
}

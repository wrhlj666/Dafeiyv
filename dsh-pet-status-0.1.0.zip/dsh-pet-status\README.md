# dsh-pet-status

把 **DeepSeek Harness 的真实工作状态**写成状态文件，供桌面桌宠（大肥鱼 / 任何能读文件的程序）显示。

**独立实现**：不依赖任何第三方桌宠插件，不启动子进程，不占端口——只订阅 DSH 的全局 `session/event`，把状态归约成一行 JSON 追加到状态文件。

## 状态文件

默认位置：

```
%LOCALAPPDATA%\dsh-pet-status\status.jsonl
```

格式为 JSONL（UTF-8，一行一条），例如：

```json
{"protocolVersion":1,"kind":"state","timestamp":1789000000000,"sessionId":"...","state":"WORKING","phase":"tool-call","stage":"执行阶段","activity":"commanding","toolName":"pwsh","project":"Dafeiyv","task":"接线桌宠","progress":{"completed":1,"total":3},"detail":"Dafeiyv · 已完成 1/3 步 · 接线桌宠"}
```

消费方只需按行读取、取**最后一条** `kind === "state"` 的消息即可。

### 状态取值

| state | 含义 | 触发 |
|---|---|---|
| `IDLE` | 空闲 | 无进行中的回合 / 回合完成 / 被中止 |
| `THINKING` | 思考中 | 回合开始、模型生成中、工具结果整理中 |
| `WORKING` | 干活中 | 正在调用工具（搜索/读取/修改/执行/测试） |
| `WAITING` | 等待你确认 | 调用了提问类工具，或回合以 `blocked` 结束 |
| `SUCCESS` | 完成 | 回合正常结束（随后立即跟一条 `IDLE`） |
| `ERROR` | 出错 | 回合异常结束（如 `max-tokens`） |

多会话同时运行时，按优先级 **WAITING > ERROR > WORKING > THINKING > IDLE** 挑一个展示。

## 安装

1. 把 `dsh-pet-status` 整个文件夹放进 DSH profile 的 `node_modules` 下：

```
<你的 .dsh 目录>\profiles\web\node_modules\dsh-pet-status\
```

2. 在 `<你的 .dsh 目录>\profiles\web\cordis.patch.yml` 的 `insert:` 列表里追加两行：

```yaml
    - id: dsh-pet-status
      name: 'dsh-pet-status'
```

3. **完全重启 DSH**（不是刷新浏览器）。

> 注意：如果之后对 profile 执行了 `pnpm install`，手工放进 `node_modules` 的包可能被清掉，重新复制一次即可。

## 配置

在 `cordis.patch.yml` 的挂载项里可加 `config`：

```yaml
    - id: dsh-pet-status
      name: 'dsh-pet-status'
      config:
        enabled: true
        includeSubagents: false
        statusFile: ''        # 留空用默认路径，也可指定绝对路径
```

| 字段 | 默认 | 说明 |
|---|---|---|
| `enabled` | `true` | 关掉后不再写状态文件 |
| `includeSubagents` | `false` | 允许子代理会话抢占状态 |
| `statusFile` | 默认路径 | 自定义状态文件位置（消费方需同步） |

## 卸载

删除 `cordis.patch.yml` 里那两行挂载项，再删掉 `node_modules\dsh-pet-status` 目录，重启 DSH 即可。

## 自测

在本插件目录下运行（需要 Node）：

```powershell
node test.mjs
```

用假 ctx + 假会话事件驱动归约器，覆盖：回合开始/思考、工具调用、待办进度、等待确认、用户回复恢复、完成（SUCCESS→IDLE）、阻塞、异常、工具级失败不误报、子代理忽略、多会话优先级。

## 消费方如何接入

本插件只负责产出状态文件，**显示端由你自己决定**（桌面宠物、悬浮窗、状态栏、脚本都行）。接入方式：

1. 按行读取状态文件，取**最后一条** `kind === "state"` 的消息
2. 按 `state` 字段驱动你的界面（见上面的状态取值表）
3. `detail` / `project` / `task` / `progress` 可用于展示文案与进度

文件是追加写的，所以支持**增量读取**：记住上次读到的字节位置，下次从那里继续；若发现文件长度小于上次位置，说明被轮转了，从头再读。

参考实现：Windows WPF 桌宠「大肥鱼」的 `DshCompanion.cs`（读文件 → 解析 → 驱动动画与气泡）。

## 与 dsh-dafeiyu 的关系

两者互不依赖，可以并存也可以二选一：

- `dsh-dafeiyu`（第三方）：自带一只 Python 桌面宠物，用 stdio 管道驱动
- `dsh-pet-status`（本插件）：只产出状态文件，显示交给别的程序

换状态源不需要改显示端代码，只要它读的是同一个状态文件格式。

/**
 * dsh-pet-status 离线自测：用假 ctx + 假会话事件驱动归约器，检查写出的状态序列。
 * 运行：node test.mjs
 */
import { readFileSync, writeFileSync, rmSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { apply } from './index.js'

const statusFile = join(tmpdir(), `dsh-pet-status-test-${process.pid}.jsonl`)
if (existsSync(statusFile)) rmSync(statusFile)

let fail = 0
const check = (label, pass, info = '') => {
  console.log(`${pass ? 'PASS' : 'FAIL'} ${label}${info ? `  [${info}]` : ''}`)
  if (!pass) fail++
}

// ---- 假 ctx：捕获事件处理器 ----
const handlers = new Map()
const ctx = {
  logger: { info: () => {}, warn: (...a) => console.log('  [warn]', ...a) },
  on: (type, handler) => {
    handlers.set(type, handler)
    return () => handlers.delete(type)
  },
  effect: (fn) => { fn() },
}

apply(ctx, { statusFile, includeSubagents: false })

const emit = (type, data = {}, seq = 1) => {
  handlers.get('session/event')?.({ header: { id: 's1', title: 'Dafeiyv' } }, { type, seq, data })
  return readStates()
}

const readStates = () => {
  if (!existsSync(statusFile)) return []
  return readFileSync(statusFile, 'utf8')
    .split('\n')
    .filter(Boolean)
    .map((line) => JSON.parse(line))
    .filter((message) => message.kind === 'state')
}

const last = () => readStates().at(-1)

// ---- 1. 启动即写一条 IDLE ----
check('启动写入 IDLE', last()?.state === 'IDLE', last()?.state)

// ---- 2. turn/start -> THINKING ----
emit('turn/start')
check('turn/start → THINKING', last()?.state === 'THINKING', last()?.detail)

// ---- 3. tool/call -> WORKING（带工具名/阶段）----
emit('tool/call', { name: 'pwsh', callId: 'c1' })
check('tool/call → WORKING', last()?.state === 'WORKING', `${last()?.state} / ${last()?.toolName}`)
check('工具名与阶段解析', last()?.toolName === 'pwsh' && last()?.stage === '执行阶段', `${last()?.toolName} / ${last()?.stage}`)

// ---- 4. todo/write -> 带进度 ----
emit('todo/write', { todos: [
  { content: '写插件', status: 'completed' },
  { content: '接线桌宠', status: 'in_progress' },
  { content: '测试', status: 'pending' },
] })
check('todo 进度写入', last()?.progress?.completed === 1 && last()?.progress?.total === 3,
  `${last()?.progress?.completed}/${last()?.progress?.total}`)
check('todo 详情含待办', String(last()?.detail).includes('接线桌宠'), last()?.detail)

// ---- 5. 等待用户确认（提问工具）----
emit('tool/result', { callId: 'c1' })          // 先让 pwsh 收尾
emit('tool/call', { name: 'ask_user_question', callId: 'c2' })
check('提问工具 → WAITING', last()?.state === 'WAITING', last()?.state)

// ---- 6. 用户回复 -> 回到 THINKING ----
emit('user/message', {})
check('user/message → 恢复 THINKING', last()?.state === 'THINKING', last()?.state)

// ---- 7. 回合完成 -> SUCCESS 然后 IDLE ----
const before = readStates().length
emit('turn/end', { reason: { kind: 'completed' } })
const after = readStates().slice(before)
check('turn/end completed → SUCCESS + IDLE',
  after.length === 2 && after[0].state === 'SUCCESS' && after[1].state === 'IDLE',
  after.map((m) => m.state).join(' → '))

// ---- 8. 回合被阻塞 -> WAITING ----
emit('turn/end', { reason: { kind: 'blocked' } })
check('turn/end blocked → WAITING', last()?.state === 'WAITING', last()?.state)

// ---- 9. 回合异常 -> ERROR ----
emit('turn/end', { reason: { kind: 'max-tokens' } })
check('turn/end max-tokens → ERROR', last()?.state === 'ERROR', last()?.state)

// ---- 10. 工具级失败不打扰（保持 WORKING/THINKING）----
emit('turn/start')
emit('tool/call', { name: 'pwsh', callId: 'c3' })
emit('tool/result', { callId: 'c3', error: { code: 'E1' } })
check('工具失败不误报 ERROR', last()?.state === 'THINKING', last()?.state)

// ---- 11. 子代理事件默认忽略 ----
const countBefore = readStates().length
handlers.get('session/event')?.(
  { header: { id: 'sub1', origin: 'subagent', title: 'sub' } },
  { type: 'tool/call', seq: 1, data: { name: 'pwsh' } },
)
check('子代理默认忽略', readStates().length === countBefore, `${countBefore} → ${readStates().length}`)

// ---- 12. 多会话优先级：WAITING 压过 WORKING ----
handlers.get('session/event')?.({ header: { id: 's2', title: 'B' } }, { type: 'tool/call', seq: 1, data: { name: 'pwsh', callId: 'x1' } })
handlers.get('session/event')?.({ header: { id: 's3', title: 'C' } }, { type: 'tool/call', seq: 1, data: { name: 'ask_user_question', callId: 'x2' } })
check('多会话取最高优先级', last()?.state === 'WAITING' && last()?.project === 'C',
  `${last()?.state} / ${last()?.project}`)

rmSync(statusFile, { force: true })
console.log(fail === 0 ? '\nALL PASS' : `\n${fail} FAILED`)
process.exit(fail === 0 ? 0 : 1)
